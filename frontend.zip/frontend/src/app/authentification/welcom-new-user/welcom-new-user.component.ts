import { Component } from '@angular/core';

@Component({
  selector: 'app-welcom-new-user',
  templateUrl: './welcom-new-user.component.html',
  styleUrls: ['./welcom-new-user.component.css']
})
export class WelcomNewUserComponent {

}
