

export interface RoleRecord {
    roleName: string;
    description: string;
  }


  