

export interface UserRecord {
    username: string;
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    roles: string[];
  }