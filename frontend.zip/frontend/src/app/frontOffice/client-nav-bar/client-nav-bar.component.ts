import { Component } from '@angular/core';

@Component({
  selector: 'app-client-nav-bar',
  templateUrl: './client-nav-bar.component.html',
  styleUrls: ['./client-nav-bar.component.css']
})
export class ClientNavBarComponent {

}
